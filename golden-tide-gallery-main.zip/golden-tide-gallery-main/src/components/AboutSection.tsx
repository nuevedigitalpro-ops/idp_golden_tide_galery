import useScrollReveal from '@/hooks/useScrollReveal';
import cherryBlossoms from '@/assets/cherry-blossoms.jpg';

const AboutSection = () => {
  const ref = useScrollReveal();

  return (
    <section id="a-propos" className="py-24 relative overflow-hidden canvas-texture" ref={ref}>
      {/* Cherry blossom background */}
      <div className="absolute inset-0">
        <img
          src={cherryBlossoms}
          alt="Cerisiers en fleurs"
          className="w-full h-full object-cover opacity-25"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background/90 via-background/70 to-background/90" />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="grid md:grid-cols-5 gap-12 items-center">
          {/* Text - takes 3 cols, offset for asymmetry */}
          <div className="md:col-span-3 md:col-start-1 scroll-reveal">
            <p className="text-sm tracking-[0.3em] uppercase text-mauve font-display not-italic mb-2">
              ✦ Notre Univers
            </p>
            <h2 className="font-display text-5xl md:text-7xl font-bold text-foreground leading-[0.9] mb-8">
              À Propos
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-secondary via-primary to-accent mb-8" />
            <p className="text-lg md:text-xl leading-relaxed text-foreground/80 mb-6 max-w-xl">
              Notre galerie est un sanctuaire où l'esprit de l'ukiyo-e rencontre
              la passion de la peinture romantique européenne. Chaque œuvre est une
              fenêtre vers un monde onirique — où les vagues dorées déferlent sous
              des ciels de mauve, et les cerisiers dansent dans la brume.
            </p>
            <p className="text-lg md:text-xl leading-relaxed text-foreground/80 max-w-xl">
              Fondée en 2020, nous célébrons l'art qui transcende les frontières —
              sauvage mais somptueux, naturel mais surréel. Chaque toile raconte une
              histoire entre le visible et l'invisible, entre l'Orient et l'Occident.
            </p>
          </div>

          {/* Decorative element - overlapping cards */}
          <div className="md:col-span-2 relative scroll-reveal" style={{ transitionDelay: '0.3s' }}>
            <div className="relative">
              <div className="w-48 h-64 bg-secondary/30 absolute -top-4 -left-4 -rotate-6" />
              <div className="w-48 h-64 bg-primary/20 absolute -bottom-4 -right-4 rotate-3" />
              <div className="relative bg-background/80 backdrop-blur-sm p-8 border border-primary/30">
                <p className="font-display text-6xl font-bold text-primary mb-2 not-italic">200+</p>
                <p className="text-foreground/60 text-sm uppercase tracking-widest font-display not-italic">Œuvres exposées</p>
                <div className="w-full h-px bg-gradient-to-r from-transparent via-primary/40 to-transparent my-6" />
                <p className="font-display text-6xl font-bold text-salmon mb-2 not-italic">47</p>
                <p className="text-foreground/60 text-sm uppercase tracking-widest font-display not-italic">Artistes du monde</p>
                <div className="w-full h-px bg-gradient-to-r from-transparent via-secondary/40 to-transparent my-6" />
                <p className="font-display text-6xl font-bold text-accent mb-2 not-italic">∞</p>
                <p className="text-foreground/60 text-sm uppercase tracking-widest font-display not-italic">Rêves partagés</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
