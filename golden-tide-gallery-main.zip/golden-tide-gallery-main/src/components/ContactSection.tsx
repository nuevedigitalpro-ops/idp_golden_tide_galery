import useScrollReveal from '@/hooks/useScrollReveal';
import { useState } from 'react';

const ContactSection = () => {
  const ref = useScrollReveal();
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
    setTimeout(() => setSent(false), 3000);
  };

  return (
    <section id="contact" className="py-24 px-6 watercolor-wash canvas-texture relative" ref={ref}>
      <div className="container mx-auto max-w-4xl">
        <div className="text-center mb-16 scroll-reveal">
          <p className="text-sm tracking-[0.3em] uppercase text-turquoise font-display not-italic">
            ✦ Restons en Contact
          </p>
          <h2 className="font-display text-5xl md:text-7xl font-bold text-foreground leading-[0.9] mt-2">
            Écrivez-nous
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-accent via-primary to-secondary mx-auto mt-4" />
        </div>

        <form onSubmit={handleSubmit} className="grid md:grid-cols-2 gap-6 scroll-reveal" style={{ transitionDelay: '0.2s' }}>
          <div className="space-y-2">
            <label className="font-display text-sm uppercase tracking-widest text-foreground/60 not-italic">Votre Nom</label>
            <input
              type="text"
              required
              className="w-full px-4 py-3 bg-background/50 backdrop-blur-sm border border-primary/30 font-body italic text-foreground focus:outline-none focus:border-primary focus:shadow-[var(--shadow-golden)] transition-all duration-300"
            />
          </div>
          <div className="space-y-2">
            <label className="font-display text-sm uppercase tracking-widest text-foreground/60 not-italic">Email</label>
            <input
              type="email"
              required
              className="w-full px-4 py-3 bg-background/50 backdrop-blur-sm border border-primary/30 font-body italic text-foreground focus:outline-none focus:border-primary focus:shadow-[var(--shadow-golden)] transition-all duration-300"
            />
          </div>
          <div className="md:col-span-2 space-y-2">
            <label className="font-display text-sm uppercase tracking-widest text-foreground/60 not-italic">Votre Message</label>
            <textarea
              rows={5}
              required
              className="w-full px-4 py-3 bg-background/50 backdrop-blur-sm border border-primary/30 font-body italic text-foreground focus:outline-none focus:border-primary focus:shadow-[var(--shadow-golden)] transition-all duration-300 resize-none"
            />
          </div>
          <div className="md:col-span-2 flex justify-center">
            <button
              type="submit"
              className="px-12 py-4 bg-primary text-primary-foreground font-display text-lg font-semibold not-italic tracking-wide hover:shadow-[var(--shadow-golden)] transition-all duration-500 hover:-translate-y-1"
            >
              {sent ? '✦ Message Envoyé ✦' : 'Envoyer le Message'}
            </button>
          </div>
        </form>
      </div>
    </section>
  );
};

export default ContactSection;
