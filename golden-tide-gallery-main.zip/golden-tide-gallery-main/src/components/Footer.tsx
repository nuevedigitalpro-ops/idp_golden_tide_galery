const Footer = () => (
  <footer className="py-12 px-6 border-t border-primary/20 canvas-texture relative">
    <div className="container mx-auto text-center relative z-10">
      <p className="font-display text-3xl font-bold text-primary not-italic mb-2">波桜</p>
      <p className="text-foreground/50 text-sm tracking-widest uppercase font-display not-italic">
        Nami Sakura — Galerie d'Art Onirique
      </p>
      <div className="w-16 h-px bg-gradient-to-r from-transparent via-primary/40 to-transparent mx-auto my-6" />
      <p className="text-foreground/40 text-xs">
        © 2024 Nami Sakura. Tous droits réservés. Fait avec 🎨 et ✨
      </p>
    </div>
  </footer>
);

export default Footer;
