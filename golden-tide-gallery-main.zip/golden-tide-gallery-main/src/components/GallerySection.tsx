import useScrollReveal from '@/hooks/useScrollReveal';
import gallery1 from '@/assets/gallery-1.jpg';
import gallery2 from '@/assets/gallery-2.jpg';
import gallery3 from '@/assets/gallery-3.jpg';
import gallery4 from '@/assets/gallery-4.jpg';
import gallery5 from '@/assets/gallery-5.jpg';
import gallery6 from '@/assets/gallery-6.jpg';

const artworks = [
  { src: gallery1, title: 'Koi Doré', subtitle: 'Huile sur toile, 2024', span: 'col-span-2 row-span-2' },
  { src: gallery2, title: 'Brume d\'Ambre', subtitle: 'Acrylique, 2024', span: 'col-span-1 row-span-1' },
  { src: gallery3, title: 'La Grande Vague', subtitle: 'Huile sur toile, 2023', span: 'col-span-1 row-span-2' },
  { src: gallery4, title: 'Sakura Portrait', subtitle: 'Huile sur bois, 2024', span: 'col-span-1 row-span-1' },
  { src: gallery5, title: 'Pont de Lotus', subtitle: 'Aquarelle, 2023', span: 'col-span-2 row-span-1' },
  { src: gallery6, title: 'Torii Sacré', subtitle: 'Huile sur toile, 2024', span: 'col-span-1 row-span-1' },
];

const GallerySection = () => {
  const ref = useScrollReveal();

  return (
    <section id="galerie" className="py-24 px-6 watercolor-wash canvas-texture relative" ref={ref}>
      <div className="container mx-auto">
        {/* Title - asymmetric, overflowing */}
        <div className="mb-16 -ml-4 md:-ml-12">
          <p className="text-sm tracking-[0.3em] uppercase text-salmon font-display not-italic scroll-reveal">
            ✦ Collection Permanente
          </p>
          <h2
            className="font-display text-5xl md:text-7xl lg:text-8xl font-bold text-foreground leading-[0.9] scroll-reveal"
            style={{ transitionDelay: '0.2s' }}
          >
            La Galerie
          </h2>
          <div className="w-32 h-1 bg-gradient-to-r from-primary via-secondary to-accent mt-4 scroll-reveal" style={{ transitionDelay: '0.3s' }} />
        </div>

        {/* Organic mosaic grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3 md:gap-4 auto-rows-[200px] md:auto-rows-[250px]">
          {artworks.map((art, i) => (
            <div
              key={i}
              className={`${art.span} scroll-reveal group relative overflow-hidden cursor-pointer`}
              style={{ transitionDelay: `${i * 0.15}s` }}
            >
              <img
                src={art.src}
                alt={art.title}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                loading="lazy"
              />
              {/* Watercolor overlay on hover */}
              <div className="absolute inset-0 bg-gradient-to-t from-foreground/70 via-foreground/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex flex-col justify-end p-4 md:p-6">
                <h3 className="font-display text-xl md:text-2xl font-bold text-cream not-italic">{art.title}</h3>
                <p className="text-cream/80 text-sm">{art.subtitle}</p>
              </div>
              {/* Brushstroke corner accent */}
              <div className="absolute top-2 right-2 w-8 h-8 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <svg viewBox="0 0 32 32" className="w-full h-full">
                  <circle cx="16" cy="16" r="12" fill="none" stroke="hsl(43 90% 61%)" strokeWidth="2" opacity="0.6" />
                </svg>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default GallerySection;
