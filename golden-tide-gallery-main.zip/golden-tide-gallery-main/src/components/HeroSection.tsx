import heroPainting from '@/assets/hero-painting.jpg';

const HeroSection = () => {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden canvas-texture">
      {/* Background image */}
      <div className="absolute inset-0">
        <img
          src={heroPainting}
          alt="Vague dorée sous un soleil levant avec cerisiers"
          className="w-full h-full object-cover"
          loading="eager"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/30 via-transparent to-background/80" />
      </div>

      {/* Content - asymmetric positioning */}
      <div className="relative z-10 container mx-auto px-6 pt-32">
      <div className="max-w-4xl mx-auto text-center">
          <p className="text-sm tracking-[0.4em] uppercase mb-4 text-primary font-display font-normal animate-wave">
            ✦ Galerie d'Art Onirique ✦
          </p>
          <h1
            className="text-6xl md:text-8xl lg:text-9xl font-bold leading-[0.9] mb-6 animate-watercolor-in drop-shadow-[0_4px_30px_rgba(0,0,0,0.5)]"
            style={{
              fontFamily: "'Cormorant Garamond', serif",
              fontStyle: 'normal',
              color: '#fefaf4',
              textShadow: '0 2px 20px rgba(0,0,0,0.6), 0 0 60px hsl(43 90% 61% / 0.4)',
            }}
          >
            Entre
            <br />
            Vague
            <br />
            & Cerisier
          </h1>
          <p className="text-xl md:text-2xl text-cream max-w-lg mx-auto font-body italic leading-relaxed" style={{ textShadow: '0 2px 10px rgba(0,0,0,0.5)' }}>
            Là où les vagues dorées rencontrent les pétales roses,
            <br />
            l'art devient un rêve éveillé.
          </p>
          <div className="mt-10 flex gap-4 justify-center">
            <a
              href="#galerie"
              className="px-8 py-3 bg-primary text-primary-foreground font-display text-lg font-semibold not-italic tracking-wide hover:shadow-[var(--shadow-golden)] transition-all duration-500 hover:-translate-y-1"
            >
              Explorer la Galerie
            </a>
            <a
              href="#a-propos"
              className="px-8 py-3 border-2 border-primary text-primary font-display text-lg font-semibold not-italic tracking-wide hover:bg-primary/10 transition-all duration-500"
            >
              Notre Histoire
            </a>
          </div>
        </div>
      </div>

      {/* Diagonal bottom edge */}
      <div className="absolute bottom-0 left-0 right-0 h-24 bg-background" style={{ clipPath: 'polygon(0 100%, 100% 40%, 100% 100%)' }} />
    </section>
  );
};

export default HeroSection;
