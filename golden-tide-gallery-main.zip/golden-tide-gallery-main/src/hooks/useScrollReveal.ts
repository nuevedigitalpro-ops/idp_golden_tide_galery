import { useEffect, useRef } from 'react';

const useScrollReveal = () => {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('revealed');
          }
        });
      },
      { threshold: 0.15 }
    );

    const el = ref.current;
    if (el) {
      el.querySelectorAll('.scroll-reveal').forEach((child) => observer.observe(child));
      if (el.classList.contains('scroll-reveal')) observer.observe(el);
    }

    return () => observer.disconnect();
  }, []);

  return ref;
};

export default useScrollReveal;
